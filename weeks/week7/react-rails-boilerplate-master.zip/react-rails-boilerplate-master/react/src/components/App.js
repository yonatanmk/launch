import React, { Component }  from 'react';

class App extends Component {
  constructor(props) {
    super(props);
  }


  render() {

    return(
      <div>
        dope
      </div>
    )
  }
}

export default App;
