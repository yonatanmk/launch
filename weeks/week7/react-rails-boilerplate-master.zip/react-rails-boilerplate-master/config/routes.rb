Rails.application.routes.draw do
  root "home#index"
end
